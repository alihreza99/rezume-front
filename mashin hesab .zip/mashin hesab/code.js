    let screen = document.querySelector('.screen');
    let buttons = document.querySelectorAll('.btn');
    let clear = document.getElementById('btn-clear');
    let equal = document.querySelector('.btn-equal');
    let v = document.getElementById('vois');
    let j = 0;
    
    buttons.forEach(function(button){
      button.addEventListener('click', function(e){
        v.play();
        screen.value = screen.value.replace(',','');
        let s = document.getElementById("answer");
          s.style.background = 'green';
          let value = e.target.dataset.num;
          if(value == "+" || value == "-" || value == "*" || value == "/" || value == ".")
          {
            j = 0;
          }
          
          if( j != 0)
          {
            screen.value = '';
             j = 0;
          }

        

        
        screen.value +=  value;
        
      })
    });
    
    equal.addEventListener('click', function(e){
      if(screen.value === ''){
        screen.value = 'Please Enter a Value';
      } else {
        let answer = eval(screen.value);
        
        screen.value = answer.toLocaleString();
        

        if(answer >= 0)
        {
          let s = document.getElementById("answer");
          s.style.background = 'green';
        }
        else
        {
          let s = document.getElementById("answer");
          s.style.background = 'red';
        }
        j = 1;
        
      }
    })
    



    clear.addEventListener('click', function(e){
      screen.value = '';
      
      
    })