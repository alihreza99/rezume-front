let b = document.getElementById("adder");
let i=1;
let last;
var modal = document.getElementById("myModal");


var span = document.getElementsByClassName("close")[0];

span.onclick = function() {
  modal.style.display = "none";
}


window.onclick = function(event) {
  if (event.target == modal) {

    modal.style.display = "none";
  }
}

function add()
{
    const val = document.querySelector('input').value;
    const val2 = document.querySelector('textarea').value;
    if(val == "" || val2 == "")
    {
      alert("please enter name and info");
    }
    else{
    let item = document.createElement("button");
    item.style.height = "35px";
    item.style.width = "70px";
    item.style.borderRadius = "5px";
    item.innerText="item " + i;
    item.setAttribute("id", "draggable"+i)
    item.setAttribute("draggable", "true")
    item.setAttribute("ondragstart", "drag(event)")
    
    let val3 = new Date();
    let p = document.createElement("p");
    item.addEventListener("click", function(){

      p.innerHTML = val + " " + val2;
      
      var count =  document.getElementById("modal-content").childElementCount;
      console.log(count);
      
      
      document.getElementById("modal-content").appendChild(p);

      modal.style.display = "block";
      if(count > 1)
      {
        document.getElementById("modal-content").removeChild(last);
      }
      last = p;
    });
    item.style.marginTop = "10px";
    i++;
    item.style.background="#708090";
    document.getElementById("pesar").appendChild(item);
    
    }
}

function allowDrop1(ev) {
  ev.preventDefault();
}

function allowDrop2(ev) {
  ev.preventDefault();
  }
  
  function drag(ev) {
    ev.dataTransfer.setData("text", ev.target.id);
  }
  
  function drop1(ev) {
    ev.preventDefault();
    var data = ev.dataTransfer.getData("text");
    ev.target.appendChild(document.getElementById(data));
  }
  function drop2(ev) {
    ev.preventDefault();
    var data = ev.dataTransfer.getData("text");
    ev.target.appendChild(document.getElementById(data));
  }
