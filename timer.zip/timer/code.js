var s = 1;
var t1 = 0;
var t2 = 0;
var i = 0;
var time;
var p1  = document.getElementById("text1");
var p2  = document.getElementById("text2");
var add = document.getElementById("start");
var stop = document.getElementById("end");
var del = document.getElementById("clear");
p1.innerHTML = "0" + t1;
p2.innerHTML = "0" + t2;
var Interval;

add.onclick = function() {
    
    clearInterval(Interval);
     Interval = setInterval(start, 100);
  }



stop.onclick = function()
{
    clearInterval(Interval);
}



del.onclick = function(){


    t1 = 00;
    t2 = 00;
    p1.innerHTML = "0" + t1;
    p2.innerHTML = "0" + t2; 
}



function start()
{
    t1++;
        if(t1<=9)
        {
           p1.innerHTML = "0" + t1;
        }
        if(t1>9 && t1<=59)
        {
            p1.innerHTML = t1;
        }
        if(t1>59 && t2<10)
        {
            t2++;
            p2.innerHTML ="0" + t2;
            t1 = 0;
        }
        if(t2 > 9 && t2 <= 59)
        {
            p2.innerHTML = t2;
            t2++;
        }
        if(t2 > 60)
        {
            alert("tamam");
            clearInterval(Interval);
            t1 = 00;
            t2 = 00;
            p1.innerHTML = "0" + t1;
            p2.innerHTML = "0" + t2; 
        }

}